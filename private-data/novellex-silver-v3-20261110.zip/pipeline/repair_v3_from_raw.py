#!/usr/bin/env python3
"""NovelLex conservative v3 partial-silver curation from user-provided v1 dataset.

Resolves audit-flagged ambiguities, checks EPUB source exactly, holds out an
entire training-unseen book for dev, and writes an explicit NOT GOLD training set.
It does NOT hallucinate manual approvals or treat unlabelled text as gold negatives.
"""
import collections
import csv
import hashlib
import json
from pathlib import Path
import random
import re
import sys
import zipfile

SEED=20261110
ROOT=Path('/mnt/data/novellex_build')
DATA=ROOT/'dataset'
OUT=Path('/mnt/data/novellex_v3')
OUT.mkdir(parents=True,exist_ok=True)
ORIG=Path('/mnt/data/NovelLex_10_EPUB_2800_Silver_Dataset_20261110.zip')
EXPECTED='d82c5434e01a9cd417a3f6637b56ebb403ea1f41e9500f132bdecfa313096729'
GOLD_STATUS='UNREVIEWED_PARTIAL_SILVER_NOT_GOLD'

# Policy deliberately errs toward abstention for contested taxonomy.
UNRESOLVED={
 'Giantsbane': 'fixed_by_relabel',
 'Slee': 'fixed_by_relabel',
 'Earth': 'real_world_not_fictional_place',
 'conjurer': 'occupation_not_unique_title',
 'conjurers': 'occupation_not_unique_title',
 'augmenter': 'class_not_unique_title',
 'augmenters': 'class_not_unique_title',
 'Damascus Steel': 'real_world_material_not_fantasy_concept',
 'Dungeon': 'generic_location_or_world_concept',
 'Sanctum of Sleep': 'organization_or_concept_ambiguous',
 'Two Elements Sunrise Array': 'formation_vs_technique_unresolved',
 'Mithril': 'generic_material',
 'Krath\'lath': 'creature_or_title_unresolved',
}
SUSPICIOUS={s.casefold():r for s,r in UNRESOLVED.items() if not r.startswith('fixed_by_relabel')}
REMAP={('defiance_of_the_fall','Giantsbane'): 'personal title', ('chrysalis','Slee'): 'fictional person'}
# Cross-validated against audited passages; still NOT human approved.
EXTRA={
 'chrysalis': {'Spineta Lacertos':'fictional creature species'},
 'primal_hunter': {'Quickstep':'named fantasy technique','Lina':'fictional person'},
 'spellcraft': {'Stefan':'fictional person'},
 'first_legendary_beast_master_tr': {'Axel':'fictional person','Drake':'fictional person','Yenileyici Yıldırım':'named fantasy technique'},
}

def rows(path):
 return [json.loads(s) for s in path.read_text(encoding='utf-8').splitlines() if s.strip()]

def sha(b): return hashlib.sha256(b).hexdigest()

def write_jsonl(path,items):
 with path.open('w',encoding='utf-8') as f:
  for r in items:f.write(json.dumps(r,ensure_ascii=False,sort_keys=True)+'\n')

# Full source exactness is mandatory for this candidate build.
assert sha(ORIG.read_bytes())==EXPECTED
source={(x['book'],int(x['chapter_index'])):x for x in rows(ROOT/'chapters_internal.jsonl')}
source_info=json.loads((ROOT/'source_inventory.json').read_text())
orig_manifest=json.loads((DATA/'manifest.json').read_text())
assert source_info==orig_manifest['source_inventory']
assert len(source)==717
for c in rows(DATA/'chapter_manifest.jsonl'):
 orig=source[(c['book'],c['chapter_index'])]
 assert sha(orig['text'].encode())==c['source_sha256']
for s in source_info:
 p=Path('/mnt/data')/s['filename']
 assert p.is_file() and sha(p.read_bytes())==s['epub_sha256']

seed=json.loads((DATA/'seed_lexicon.json').read_text())
lexicon={book:{(label,term) for label,terms in cats.items() for term in terms} for book,cats in seed.items()}
raw=[]
for split in ('train','dev','tr_train','tr_dev'):
 texts=rows(DATA/(split+'.jsonl'))
 audits=rows(DATA/(split+'_audit.jsonl'))
 assert len(texts)==len(audits)
 for row,audit in zip(texts,audits):
  txt=row['input'];ch=source[(audit['book'],audit['chapter'])]
  assert ch['text'][audit['chapter_start']:audit['chapter_end']]==txt
  for span in audit['spans']:
   assert txt[span['start']:span['end']] in row['output']['entities'][span['label']]
  raw.append((split,txt,audit))

COUNTS=collections.Counter()
PROBLEM=collections.Counter()
AMBIGUOUS=[]
R=[]

def check_not_crossing(spans):
 spans.sort(key=lambda s:(s['start'],-s['end']))
 out=[]
 for span in spans:
  if any(span['start']<a['end'] and a['start']<span['end'] for a in out):
   PROBLEM['overlap_removed']+=1
   continue
  out.append(span)
 return out

def add_missing(text,book,spans):
 for term,label in EXTRA.get(book,{}).items():
  for m in re.finditer(r'(?<!\w)'+re.escape(term)+r'(?!\w)',text):
   a,b=m.span()
   if any(a<x['end'] and x['start']<b for x in spans):continue
   # Simple word matching is only a candidate; source remains unreviewed.
   spans.append({'start':a,'end':b,'label':label,'source':'audit_context_candidate_not_gold'})
   COUNTS['additional_candidate_spans']+=1
 return spans

def trim(text,spans,limit=470):
 """Select a source-faithful excerpt around strongest span cluster; no split span."""
 if len(text)<=limit:return text,spans,0
 weights=[2 if x['label']!='fictional person' else 1 for x in spans]
 scores=[]
 for i,s in enumerate(spans):
  a=max(0,min(s['start']-100,len(text)-limit));b=a+limit
  w=sum(weights[k] for k,t in enumerate(spans) if t['start']>=a and t['end']<=b)
  scores.append((w,-abs(a-(len(text)-limit)//2),a))
 start=max(scores)[2];end=start+limit
 # shift to nearby word bounds without excluding selected spans, else keep exact and skip partials.
 while start<end and start>0 and text[start-1].isalnum() and text[start].isalnum():start+=1
 while end>start and end<len(text) and text[end-1].isalnum() and text[end].isalnum():end-=1
 subset=[]
 for x in spans:
  if x['start']>=start and x['end']<=end:subset.append({**x,'start':x['start']-start,'end':x['end']-start})
 return text[start:end],subset,start

for split,txt,a in raw:
 book=a['book'];spans=[]
 for s in a['spans']:
  term=txt[s['start']:s['end']];lab=s['label'];src=s['source']
  if term.casefold() in SUSPICIOUS:
   PROBLEM['excluded_ambiguous_mention']+=1
   AMBIGUOUS.append({'example_id':a['id'],'term':term,'old_label':lab,'reason':SUSPICIOUS[term.casefold()],'split':split})
   continue
  if (book,term) in REMAP:
   newlab=REMAP[(book,term)]
   if lab!=newlab:
    PROBLEM['retagged_known_audit_issue']+=1
    lab=newlab;src='audit_relabel_candidate_not_gold'
  if src=='pilot_teacher_provisional' and (s['label'],term) not in lexicon.get(book,set()):
   PROBLEM['teacher_only_removed_unverified']+=1
   AMBIGUOUS.append({'example_id':a['id'],'term':term,'old_label':s['label'],'reason':'teacher_only_not_correlated_with_lexicon','split':split})
   continue
  spans.append({**s,'label':lab,'source':src})
 spans=add_missing(txt,book,spans)
 spans=check_not_crossing(spans)
 if not spans:
  PROBLEM['empty_after_abstention']+=1;continue
 text,spans,offset=trim(txt,spans)
 if not spans:
  PROBLEM['empty_after_trim']+=1;continue
 # A repeated entity surface with ambiguous class is unsupervisable with string-only GLiNER output.
 labelterms=collections.defaultdict(set);by_term=collections.defaultdict(set)
 for s in spans:
  term=text[s['start']:s['end']];labelterms[s['label']].add(term);by_term[term].add(s['label'])
 if any(len(labels)>1 for labels in by_term.values()):
  PROBLEM['cross_label_surface_row_dropped']+=1;continue
 # Reject if any surface appears unannotated again within this shortened excerpt.
 if any(text.count(term)!=sum(text[t['start']:t['end']]==term for t in spans) for term in by_term):
  PROBLEM['unaccounted_surface_collision_row_dropped']+=1;continue
 # Any trimmed excerpt must match exact source chapter range.
 start=a['chapter_start']+offset
 assert source[(book,a['chapter'])]['text'][start:start+len(text)]==text
 newaudit={**a,'spans':spans,'chapter_start':start,'chapter_end':start+len(text),'word_count':len(text.split()),
           'curation':'audit_guided_silver_v3_not_gold','human_gold_verified':False,
           'precuration_id':a['id']}
 newaudit['id']=sha((book+'|'+str(a['chapter'])+'|'+str(start)+'|'+text).encode())[:24]
 labels={label:sorted(terms) for label,terms in sorted(labelterms.items())}
 sample={'input':text,'output':{'entities':labels}}
 # Unit invariants
 assert len(text)>130 and len(text)<=470
 assert spans==check_not_crossing(spans[:])
 for s in spans:assert 0<=s['start']<s['end']<=len(text) and text[s['start']:s['end']] in labels[s['label']]
 R.append({'original_split':split,'book':book,'chapter':a['chapter'],'sample':sample,'audit':newaudit})

# Stronger book-disjoint development: NO spellcraft chapters used in training.
parts={'train':[],'dev':[],'tr_train':[],'tr_dev':[]}
for r in R:
 if r['book']=='mother_of_learning':raise AssertionError('Test leaked into train')
 dest=('dev' if r['book']=='spellcraft' else 'train') if not r['book'].endswith('_tr') else r['original_split']
 r['audit']['split']=dest
 parts[dest].append(r)

# Near-perfect duplicates are forbidden within or across splits; book-level disjoint EN.
seen={}; ids=set()
for split,values in parts.items():
 for r in values:
  audit=r['audit'];key=sha(r['sample']['input'].encode())
  assert key not in seen,('duplicate text',split,seen.get(key))
  seen[key]=split
  assert audit['id'] not in ids;ids.add(audit['id'])
 assert all(r['book']!='mother_of_learning' for r in values)
assert {r['book'] for r in parts['train']}.isdisjoint({r['book'] for r in parts['dev']})
assert len(parts['train'])>=2000,len(parts['train'])
assert len(parts['dev'])>=200,len(parts['dev'])

# English train stays unmodified by Turkish. Keep original holdout only for provisional recall monitoring.
hold=rows(DATA/'holdout_teacher_provisional_only.jsonl')
assert len(hold)==25
for split,values in parts.items():
 write_jsonl(OUT/(split+'.jsonl'),[r['sample'] for r in values]);write_jsonl(OUT/(split+'_audit.jsonl'),[r['audit'] for r in values])
write_jsonl(OUT/'holdout_teacher_provisional_only.jsonl',hold)

# Bounded stratified fresh review queue with unambiguous offsets and stable IDs, no gold claims.
review=[]
for split in ('train','dev','tr_train','tr_dev'):
 for r in parts[split]:
  a=r['audit'];txt=r['sample']['input']
  for s in a['spans']:
   review.append({'id':a['id']+':'+str(s['start'])+':'+str(s['end']),
     'example_id':a['id'],'split':split,'book':r['book'],'chapter':r['chapter'],
     'start':s['start'],'end':s['end'],'term':txt[s['start']:s['end']],
     'label':s['label'],'source':s['source'],'context':txt[max(0,s['start']-70):min(len(txt),s['end']+70)],
     'review_status':'PENDING','corrected_label':'','notes':''})
random.Random(SEED).shuffle(review)
# Round-robin by label to avoid only-person queue; no manual approvals inferred.
bylabel=collections.defaultdict(list)
for row in review:bylabel[row['label']].append(row)
strat=[]
labels=sorted(bylabel,key=lambda x:len(bylabel[x]))
while len(strat)<300 and any(bylabel.values()):
 for lab in labels:
  if len(strat)>=300:break
  if bylabel[lab]:strat.append(bylabel[lab].pop())
with (OUT/'review_queue_offset_300.csv').open('w',encoding='utf-8',newline='') as f:
 writer=csv.DictWriter(f,fieldnames=list(strat[0]));writer.writeheader();writer.writerows(strat)

summ={split:{'contexts':len(vals),'mentions':sum(len(r['audit']['spans']) for r in vals),
  'books':dict(collections.Counter(r['book'] for r in vals)),
  'labels':dict(collections.Counter(s['label'] for r in vals for s in r['audit']['spans'])),
  'sources':dict(collections.Counter(s['source'] for r in vals for s in r['audit']['spans']))}
 for split,vals in parts.items()}
manifest={
 'version':'novellex_v3_conservative_abstention','date':'2026-11-10',
 'status':GOLD_STATUS,'human_gold_samples':0,
 'source_package_sha256':EXPECTED,'epub_verified_sha256_count':10,
 'chapter_sha256_verified_count':717,
 'original_passage_exact_slice_verified_count':3729,
 'original_label_status':'rule_dictionary_plus_teacher_provisional',
 'changes':dict(PROBLEM),'new_candidate_mentions':COUNTS['additional_candidate_spans'],
 'dev_book':'spellcraft','training_excludes_dev_book':True,
 'evaluation_policy':'known-positive silver recall only; NO precision/F1, no promotion decision',
 'limits':['No user/independent expert has adjudicated the 300 queue rows',
   'Nonmentioned real entities can still become implicit negatives in GLiNER training',
   'Spellcraft dev is book-disjoint from train weights but lexicon authors saw that text',
   'Original Mother of Learning 25 positives have already been examined repeatedly and are NOT independent gold',
   'English-only candidate training; Turkish data isolated',
   'Source snippets copyrighted: private handling only'],
 'splits':summ,
}
(OUT/'manifest_v3.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
(OUT/'abstention_candidates.json').write_text(json.dumps(AMBIGUOUS[:300],ensure_ascii=False,indent=2),encoding='utf-8')
(OUT/'README_TR.md').write_text('''# NovelLex v3 — denetim odaklı silver deney veri seti

Gerçek EPUB metni ve önceki 2800/449/380/100 örnek temel alınmıştır. Kaynak EPUB SHA-256, 717 bölüm SHA-256 ve 3.729 orijinal pencerenin gerçek kaynak dilimi yeniden bağımsız doğrulandı. Denetimde bulunan belirsiz etiketler çıkarıldı, bazı belirli adaylar yeniden sınıflandırıldı; yeni bağlam adayları altın etiket değildir. Kısa, kaynak sadık bağlamlar kullanıldı. `spellcraft` romanının tamamı EN dev'de; EN train bu romandan hiçbir örnek içermez. Türkçe ayrı kalır. `Mother of Learning` 25 pozitif örneği yalnız geçmişten gelen provisional holdout, gold değil.

**Uyarı:** Bu hâlâ *partial silver*'dır; tüm gerçek varlıkların etiketlendiği söylenemez. GLiNER standart eğitiminde eksik etiketler örtük negatife dönüşebilir. Bu nedenle sadece kontrollü, özel LoRA araştırması için kullanılmalı; gold precision/F1 veya üretim yükseltmesi yok.

`review_queue_offset_300.csv` kayıtları karakter başlangıç/bitiş konumu ve benzersiz mention ID içerir. İnsan tarafından doldurulmamıştır. `abstention_candidates.json` özellikle çıkartılan belirsiz örnekleri içerir.
''',encoding='utf-8')

# Verify from saved files and original EPUBs in a separate pass.
for split in parts:
 assert len(rows(OUT/(split+'.jsonl')))==summ[split]['contexts']
 assert len(rows(OUT/(split+'_audit.jsonl')))==summ[split]['contexts']
for row in strat: assert row['review_status']=='PENDING'
print(json.dumps({'splits':summ,'repair_events':dict(PROBLEM),'review_queue':len(strat),'status':GOLD_STATUS},ensure_ascii=False))
