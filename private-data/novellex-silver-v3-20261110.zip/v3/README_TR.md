# NovelLex v3 — denetim odaklı silver deney veri seti

Gerçek EPUB metni ve önceki 2800/449/380/100 örnek temel alınmıştır. Kaynak EPUB SHA-256, 717 bölüm SHA-256 ve 3.729 orijinal pencerenin gerçek kaynak dilimi yeniden bağımsız doğrulandı. Denetimde bulunan belirsiz etiketler çıkarıldı, bazı belirli adaylar yeniden sınıflandırıldı; yeni bağlam adayları altın etiket değildir. Kısa, kaynak sadık bağlamlar kullanıldı. `spellcraft` romanının tamamı EN dev'de; EN train bu romandan hiçbir örnek içermez. Türkçe ayrı kalır. `Mother of Learning` 25 pozitif örneği yalnız geçmişten gelen provisional holdout, gold değil.

**Uyarı:** Bu hâlâ *partial silver*'dır; tüm gerçek varlıkların etiketlendiği söylenemez. GLiNER standart eğitiminde eksik etiketler örtük negatife dönüşebilir. Bu nedenle sadece kontrollü, özel LoRA araştırması için kullanılmalı; gold precision/F1 veya üretim yükseltmesi yok.

`review_queue_offset_300.csv` kayıtları karakter başlangıç/bitiş konumu ve benzersiz mention ID içerir. İnsan tarafından doldurulmamıştır. `abstention_candidates.json` özellikle çıkartılan belirsiz örnekleri içerir.
