# NovelLex v0.3 (PRIVATE): contextual teacher review

This is an **intermediate research artifact**, not a trained model or validated gold NER dataset.

## Source

Five EPUBs uploaded for private analysis by the user. Their first chapters were sampled;
the previously generated v0.2 partial-silver corpus remains separate.

## Contents

- `context_reviewed_v0_3.jsonl`: selected original paragraphs with AI-teacher-reviewed entity mentions and source offsets.
- `teacher_review_sheet.csv`: manual review/adjudication form.
- `uncertain_review_v0_3.jsonl`: deliberately unresolved ambiguous phrases.
- `conservative_train_subset.jsonl`: stronger but still **provisional** paragraphs with explicit labels.
- `provisional_holdout_subset.jsonl`: Mother of Learning only; separate from training.
- `manifest.json`: counts and provenance.
- `verify_dataset.py`: structural, no-leakage and span-offset checks.

## Method / caveats

1. Teacher-selected spans are not independent human gold. Samples with ambiguous word senses are flagged; they cannot be used as fully annotated negative examples.
2. Do NOT train standard BIO/NER on the entire v0.2 set treating unlabeled tokens as O. Most entities there have not been reviewed.
3. The independent *novel* holdout is `mother_of_learning`; do not include it in training or data-derived vocabularies. Its current labels are preliminary and were NOT used to train/tune a model.
4. Some span classes (e.g., TITLE, ROLE, WORLD_CONCEPT) are a working taxonomy; consistency guidelines should be independently reviewed before final training.
5. A real GLiNER fine-tune requires dependencies/model weights and GPU or appropriate hardware; **none has been run here**.
6. Do not publish the novel excerpts or training packages without checking rights.

Recommended next step: manually resolve all uncertain items, expand first-mention/one-off spans, then evaluate a ready-made model on the frozen holdout before fine-tuning.
